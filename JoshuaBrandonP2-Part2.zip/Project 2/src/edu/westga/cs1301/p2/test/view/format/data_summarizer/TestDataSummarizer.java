package edu.westga.cs1301.p2.test.view.format.data_summarizer;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.Passenger;
import edu.westga.cs1301.p2.model.Ticket;
import edu.westga.cs1301.p2.view.format.DataSummarizer;

class TestDataSummarizer {

	@Test
	void testIfNamesIsNull() {
		DataSummarizer string = new DataSummarizer();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					string.getAllNames(null);
				}
		);
	}
	
	@Test
	void testIfNamesHasNoNames() {
		DataSummarizer string = new DataSummarizer();
		ArrayList<String> names = new ArrayList<String>();
		String listOfNames = string.getAllNames(names);
		assertEquals("",listOfNames, "Checking if Strings are equal");
	}
	
	@Test
	void testIfNamesHasOneName() {
		DataSummarizer string = new DataSummarizer();
		ArrayList<String> names = new ArrayList<String>();
		String name1 = new String("Bob");
		names.add(name1);
		String listOfNames = string.getAllNames(names);
		assertEquals("Bob\n",listOfNames, "Checking if Strings are equal");
	}
	@Test
	void testIfNamesHasManyNames() {
		DataSummarizer string = new DataSummarizer();
		ArrayList<String> names = new ArrayList<String>();
		String name1 = new String("Bob");
		names.add(name1);
		String name2 = new String("Jim");
		names.add(name2);
		String listOfNames = string.getAllNames(names);
		assertEquals("Bob\nJim\n",listOfNames, "Checking if Strings are equal");
	}
	@Test
	void testIfTicketIsNull() {
		DataSummarizer string = new DataSummarizer();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					string.ticketToString(null);
				}
		);
	}
	
	@Test
	void testTicketToString() {
		DataSummarizer string = new DataSummarizer();
		Ticket ticket = new Ticket(1, 1, "A", "A");
		String ticketInfo = string.ticketToString(ticket);
		assertEquals("1 1.0 A A\n", ticketInfo, "Checking if Strings are equal");
	}
	
	@Test
	void testIfTicketsIsNull() {
		DataSummarizer string = new DataSummarizer();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					string.ticketCollectionToString(null);
				}
		);
	}
	
	@Test
	void testTicketsToStringWithOneTicket() {
		DataSummarizer string = new DataSummarizer();
		ArrayList<Ticket> tickets = new ArrayList<Ticket>();
		Ticket ticket1 = new Ticket(1, 1, "A", "A");
		tickets.add(ticket1);
		String ticketsInfo = string.ticketCollectionToString(tickets);
		assertEquals("1 1.0 A A\n", ticketsInfo, "Checking if Strings are equal");
	}
	@Test
	void testTicketsToStringWithManyTickets() {
		DataSummarizer string = new DataSummarizer();
		ArrayList<Ticket> tickets = new ArrayList<Ticket>();
		Ticket ticket1 = new Ticket(1, 1, "A", "A");
		tickets.add(ticket1);
		Ticket ticket2 = new Ticket(2, 2, "B", "B");
		tickets.add(ticket2);
		String ticketsInfo = string.ticketCollectionToString(tickets);
		assertEquals("1 1.0 A A\n2 2.0 B B\n", ticketsInfo, "Checking if Strings are equal");
	}
	@Test
	void testIfPassengerIsNull() {
		DataSummarizer string = new DataSummarizer();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					string.passengerToString(null);
				}
		);
	}
	@Test
	void testPassengerToString() {
		DataSummarizer string = new DataSummarizer();
		Passenger passenger = new Passenger("a", 1);
		String passengerInfo = string.passengerToString(passenger);
		assertEquals("a 1\n", passengerInfo, "Checking If info and String match");
	}
	

}
