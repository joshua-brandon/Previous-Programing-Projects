package edu.westga.cs1301.p2.test.model.ticket_broker;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.Passenger;
import edu.westga.cs1301.p2.model.Ticket;
import edu.westga.cs1301.p2.model.TicketBroker;

class TestTicketBroker {

	@Test
	void testTicketAddedIsNull() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.addTicket(null);
				}
		);
	}
	
	@Test
	void testTicketAddOneValidTicket() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "Atlanta", "New York");
		tickets.addTicket(ticket1);
		
		Ticket firstTicket = tickets.getTickets().get(0);
		assertEquals(1, firstTicket.getId(), "Checking if Ids are equal");
		assertEquals(1, firstTicket.getCost(), "Checking if Costs are equal");
		assertEquals("Atlanta", firstTicket.getDepartureName(), "Checking if Departure Names are equal");
		assertEquals("New York", firstTicket.getDestinationName(), "Checking if Destination Names are equal");
	}
	@Test
	void testTicketAddManyValidTickets() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "Atlanta", "New York");
		tickets.addTicket(ticket1);
		Ticket ticket2 = new Ticket(2, 2, "A", "B");
		tickets.addTicket(ticket2);
		
		Ticket firstTicket = tickets.getTickets().get(0);
		assertEquals(1, firstTicket.getId(), "Checking if Ids are equal");
		assertEquals(1, firstTicket.getCost(), "Checking if Costs are equal");
		assertEquals("Atlanta", firstTicket.getDepartureName(), "Checking if Departure Names are equal");
		assertEquals("New York", firstTicket.getDestinationName(), "Checking if Destination Names are equal");
		
		Ticket secondTicket = tickets.getTickets().get(1);
		assertEquals(2, secondTicket.getId(), "Checking if Ids are equal");
		assertEquals(2, secondTicket.getCost(), "Checking if Costs are equal");
		assertEquals("A", secondTicket.getDepartureName(), "Checking if Departure Names are equal");
		assertEquals("B", secondTicket.getDestinationName(), "Checking if Destination Names are equal");
	}
	@Test
	void testPassengerAddedIsNull() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.addPassenger(null);
				}
		);
	}
	@Test
	void testTicketAddOneValidPassenger() {
		TicketBroker tickets = new TicketBroker();
		Passenger passenger1 = new Passenger("a", 1);
		tickets.addPassenger(passenger1);
		
		Passenger firstPassenger = tickets.getPassengers().get(0);
		assertEquals("a", firstPassenger.getName(), "Checking if names are equal");
		assertEquals(1, firstPassenger.getId(), "Checking if Ids are equal");
	}
	
	@Test
	void testDepartureLocationIsNull() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getDestinationsFromDeparture(null);
				}
		);
	}
	@Test
	void testDepartureLocationIsEmpty() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getDestinationsFromDeparture("");
				}
		);
	}
	@Test
	void testNoPossibleTickets() {
		TicketBroker tickets = new TicketBroker();
		ArrayList<Ticket> result = tickets.getDestinationsFromDeparture("Atlanta");
		assertEquals(0, result.size(), "Checking if size is the same");
	}
	@Test
	void testOneMatchingDestinationInOneTicket() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "Atlanta", "New York");
		tickets.addTicket(ticket1);
		ArrayList<Ticket> result = tickets.getDestinationsFromDeparture("Atlanta");
		assertEquals(1, result.size(), "Checking if size is the same");
		
	}
	@Test
	void testOneMatchingDestinationInManyTickets() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "Atlanta", "New York");
		tickets.addTicket(ticket1);
		Ticket ticket2 = new Ticket(2, 2, "A", "B");
		tickets.addTicket(ticket2);
		
		ArrayList<Ticket> result = tickets.getDestinationsFromDeparture("Atlanta");
		assertEquals(1, result.size(), "Checking if size is the same");
	}
	@Test
	void testManyMatchingDeparturesInManyTickets() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "Atlanta", "New York");
		tickets.addTicket(ticket1);
		Ticket ticket2 = new Ticket(2, 2, "Atlanta", "B");
		tickets.addTicket(ticket2);
		
		ArrayList<Ticket> result = tickets.getDestinationsFromDeparture("Atlanta");
		assertEquals(2, result.size(), "Checking if size is the same");
	}
	@Test
	void testDepartureIsNull() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getTicketsMatchingDestinationAndDeparture(null, "A");
				}
		);
	}
	@Test
	void testDepartureIsEmpty() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getTicketsMatchingDestinationAndDeparture("", "A");
				}
		);
	}
	@Test
	void testDestinationIsNull() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getTicketsMatchingDestinationAndDeparture("A", null);
				}
		);
	}
	@Test
	void testDestinationIsEmpty() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getTicketsMatchingDestinationAndDeparture("A", "");
				}
		);
	}
	@Test
	void testNoTicketsToCheckDestinationAndDeparture() {
		TicketBroker tickets = new TicketBroker();
		ArrayList<Ticket> result = tickets.getTicketsMatchingDestinationAndDeparture("A", "B");
		assertEquals(0, result.size(), "Checking if size is the same");
	}
	@Test
	void testNoTicketsMatchDestinationAndDeparture() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "Atlanta", "New York");
		tickets.addTicket(ticket1);
		ArrayList<Ticket> result = tickets.getTicketsMatchingDestinationAndDeparture("A", "B");
		assertEquals(0, result.size(), "Checking if size is the same");
	}
	@Test
	void testOneTicketMatchesDestinationAndDepartureOutOfOne() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "A", "B");
		tickets.addTicket(ticket1);
		ArrayList<Ticket> result = tickets.getTicketsMatchingDestinationAndDeparture("A", "B");
		assertEquals(1, result.size(), "Checking if size is the same");
	}
	@Test
	void testOneTicketMatchesDestinationAndDepartureOutOfMany() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "A", "B");
		tickets.addTicket(ticket1);
		Ticket ticket2 = new Ticket(2, 2, "A", "C");
		tickets.addTicket(ticket2);
		ArrayList<Ticket> result = tickets.getTicketsMatchingDestinationAndDeparture("A", "B");
		assertEquals(1, result.size(), "Checking if size is the same");
	}
	@Test
	void testManyTicketsMatchesDestinationAndDepartureOutOfMany() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "A", "B");
		tickets.addTicket(ticket1);
		Ticket ticket2 = new Ticket(2, 2, "A", "B");
		tickets.addTicket(ticket2);
		ArrayList<Ticket> result = tickets.getTicketsMatchingDestinationAndDeparture("A", "B");
		assertEquals(2, result.size(), "Checking if size is the same");
	}
	@Test
	void testIfTicketAddedToPassengerIsNotPositive() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.addTicketToPassenger(1, 0);
				}
		);
	}
	@Test
	void testTicketAddedToPassengerAndPassengerIsNotPositive() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.addTicketToPassenger(0, 1);
				}
		);
	}
	@Test
	void testIfTicketAddedToPassengerAndTicketIdDoesNotExist() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(2, 2, "a", "a");
		tickets.addTicket(ticket1);
		Passenger passenger1 = new Passenger("a", 1);
		tickets.addPassenger(passenger1);
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.addTicketToPassenger(1, 1);
				}
		);
	}
	@Test
	void testIfTicketAddedToPassengerAndPassengerIdDoesNotExist() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "a", "a");
		tickets.addTicket(ticket1);
		Passenger passenger1 = new Passenger("a", 2);
		tickets.addPassenger(passenger1);
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.addTicketToPassenger(1, 1);
				}
		);
	}
	@Test
	void testAddValidTicketToValidPersonWithExistingIds() {
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "a", "a");
		tickets.addTicket(ticket1);
		Passenger passenger1 = new Passenger("a", 1);
		tickets.addPassenger(passenger1);
		Passenger result = tickets.addTicketToPassenger(1, 1);
		assertEquals("a", result.getName(),"Checking if name is equal");
		assertEquals(1, result.getId(), "Checking if passenger id is the same");
		assertEquals(1, result.getTickets().get(0).getId(), "Checking if ticket Id is the same");
		assertEquals(1, result.getTickets().get(0).getCost(), "Checking if ticket Cost is the same");
		assertEquals("a", result.getTickets().get(0).getDepartureName(), "Checking if ticket departure name is the same");
		assertEquals("a", result.getTickets().get(0).getDestinationName(), "Checking if ticket departure name is the same");
	}
	@Test
	void testStartLocationIsNull() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getLowestPriceTicket(null, "a");
				}
		);
	}
	@Test
	void testStartLocationIsEmpty() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getLowestPriceTicket("", "a");
				}
		);
	}
	@Test
	void testEndLocationIsNull() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getLowestPriceTicket("a", null);
				}
		);
	}
	@Test
	void testEndLocationIsEmpty() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getLowestPriceTicket("a", "");
				}
		);
	}
	@Test
	void testNoTicketsToCheckForCheapest() {
		TicketBroker tickets = new TicketBroker();
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					tickets.getLowestPriceTicket("A", "B");
				}
		);
	}
	@Test
	void testOneTicketMatchesParameters(){
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "a", "b");
		tickets.addTicket(ticket1);
		Ticket result = tickets.getLowestPriceTicket("a", "b");
		assertEquals("a", result.getDepartureName(), "Checking the Departures match");
		assertEquals("b", result.getDestinationName(), "Checking the destination macth");
	}
	@Test
	void testOneTicketMatchesParametersWithMultipleTickets(){
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "a", "b");
		tickets.addTicket(ticket1);
		Ticket ticket2 = new Ticket(2, 2, "c", "d");
		tickets.addTicket(ticket2);
		Ticket result = tickets.getLowestPriceTicket("a", "b");
		assertEquals("a", result.getDepartureName(), "Checking the Departures match");
		assertEquals("b", result.getDestinationName(), "Checking the destination macth");
	}
	@Test
	void testManyTicketMatchesParametersWithMultipleTickets(){
		TicketBroker tickets = new TicketBroker();
		Ticket ticket1 = new Ticket(1, 1, "a", "b");
		tickets.addTicket(ticket1);
		Ticket ticket2 = new Ticket(2, 2, "c", "d");
		tickets.addTicket(ticket2);
		Ticket ticket3 = new Ticket(3, 3, "a", "b");
		tickets.addTicket(ticket3);
		Ticket result = tickets.getLowestPriceTicket("a", "b");
		assertEquals("a", result.getDepartureName(), "Checking the Departures match");
		assertEquals("b", result.getDestinationName(), "Checking the destination macth");
	}
}
