package edu.westga.cs1301.p2.test;

/** Constant values needed to support unit testing.
 * 
 * @author CS 1301
 * @version Spring 2023
 */
public class TestingConstants {

	public static final double DELTA = 1e-10;

}
