package edu.westga.cs1301.p2.test.model.passenger;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.Passenger;
import edu.westga.cs1301.p2.model.Ticket;

class TestPassenger {

	@Test
	void testIfNameIsNull() {
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Passenger(null, 1);
				}
		);
	}
	@Test
	void testIfNameIsEmpty() {
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Passenger("", 1);
				}
		);
	}
	@Test
	void testIfIdIsNotPositive() {
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Passenger("a", 0);
				}
		);
	}
	@Test
	void testIfNameAndIdAreCorrect() {
		Passenger passenger = new Passenger("a", 1);
		assertEquals("a", passenger.getName(), "Checking if names are equal");
		assertEquals(1, passenger.getId(), "Checking if Ids are equal");
	}
	@Test
	void testIfTicketIsNull() {
		Passenger passenger = new Passenger("a", 1);
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					passenger.addTicketToPassengerList(null);
				}
		);
	}
	@Test
	void testAddOneTicketToPassenger() {
		Passenger passenger = new Passenger("a", 1);
		Ticket ticket = new Ticket(1, 1, "a", "a");
		passenger.addTicketToPassengerList(ticket);
		assertEquals("a", passenger.getName(), "Checking if passenger name is the same");
		assertEquals(1, passenger.getId(), "Checking if passenger id is the same");
		assertEquals(1, passenger.getTickets().get(0).getId(), "Checking if ticket Id is the same");
		assertEquals(1, passenger.getTickets().get(0).getCost(), "Checking if ticket Cost is the same");
		assertEquals("a", passenger.getTickets().get(0).getDepartureName(), "Checking if ticket departure name is the same");
		assertEquals("a", passenger.getTickets().get(0).getDestinationName(), "Checking if ticket departure name is the same");
	}
	
	@Test
	void testAddTwoTicketsToPassenger() {
		Passenger passenger = new Passenger("a", 1);
		Ticket ticket1 = new Ticket(1, 1, "a", "a");
		passenger.addTicketToPassengerList(ticket1);
		Ticket ticket2 = new Ticket(2, 2, "b", "a");
		passenger.addTicketToPassengerList(ticket2);
		assertEquals("a", passenger.getName(), "Checking if passenger name is the same");
		assertEquals(1, passenger.getId(), "Checking if passenger id is the same");
		assertEquals(1, passenger.getTickets().get(0).getId(), "Checking if ticket Id is the same");
		assertEquals(1, passenger.getTickets().get(0).getCost(), "Checking if ticket Cost is the same");
		assertEquals("a", passenger.getTickets().get(0).getDepartureName(), "Checking if ticket departure name is the same");
		assertEquals("a", passenger.getTickets().get(0).getDestinationName(), "Checking if ticket departure name is the same");
		assertEquals(2, passenger.getTickets().get(1).getId(), "Checking if ticket Id is the same");
		assertEquals(2, passenger.getTickets().get(1).getCost(), "Checking if ticket Cost is the same");
		assertEquals("b", passenger.getTickets().get(1).getDepartureName(), "Checking if ticket departure name is the same");
		assertEquals("a", passenger.getTickets().get(1).getDestinationName(), "Checking if ticket departure name is the same");
	}

}
