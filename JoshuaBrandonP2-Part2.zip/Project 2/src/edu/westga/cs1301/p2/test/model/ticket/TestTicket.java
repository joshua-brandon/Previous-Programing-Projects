package edu.westga.cs1301.p2.test.model.ticket;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.Ticket;

class TestTicket {

	@Test
	void testIdIsNotPositive() {
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Ticket(0, 1, "Atlanta", "New York");
				}
		);
	}
	@Test
	void testCostIsNotPositive() {
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Ticket(1, 0, "Atlanta", "New York");
				}
		);
	}
	@Test
	void testDepartureNameIsNull() {
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Ticket(1, 1, null, "New York");
				}
		);
	}
	@Test
	void testDepartureNameIsEmpty() {
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Ticket(1, 1, "", "New York");
				}
		);
	}
	@Test
	void testDestinationNameIsNull() {
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Ticket(1, 1, "Atlanta", null);
				}
		);
	}
	@Test
	void testDestinationNameIsEmpty() {
		assertThrows(
				IllegalArgumentException.class,
				() -> {
					new Ticket(1, 1, "Atlanta", "");
				}
		);
	}
	@Test
	void testTicketWithGoodInformation() {
		Ticket ticket = new Ticket(1, 1, "a", "b");
		assertEquals(1, ticket.getId(), "Checking if Ids are equal");
		assertEquals(1, ticket.getCost(), "Checking if Cost are equal");
		assertEquals("a", ticket.getDepartureName(), "Checking if Departure name is equal");
		assertEquals("b", ticket.getDestinationName(), "Checking if Destination name is equal");
	}

}
