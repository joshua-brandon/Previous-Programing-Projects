package edu.westga.cs1301.p2.view.format;

import java.util.ArrayList;

import edu.westga.cs1301.p2.model.Passenger;
import edu.westga.cs1301.p2.model.Ticket;

/** Summarizes the information from objects to be displayed to users.
 * 
 * @author CS 1301
 * @version Summer 2023
 */
public class DataSummarizer {
	/**Reads a list of names and returns them as a string separating each name with a newline
	 * 
	 * @param names must be valid
	 * @return String with each name
	 */
	public String getAllNames(ArrayList<String> names) {
		if (names == null) {
			throw new IllegalArgumentException("Names must be valid");
		}
		String string = "";
		for (int i = 0; i < names.size(); i++) {
			string = string + names.get(i) + "\n";
		}
		return string;
	}
	
	/** Reads a ticket and returns a string with all of the ticket information
	 * 
	 * @param ticket
	 * @return String with all the ticket information
	 */

	public String ticketToString(Ticket ticket) {
		if (ticket == null) {
			throw new IllegalArgumentException("Ticket cannot be null");
		}
		String string = ticket.getId() + " " + ticket.getCost() + " " + ticket.getDepartureName() + " " + ticket.getDestinationName() + "\n";
		return string;
	}
	
	/** Returns a String with all tickets separated by newlines
	 * 
	 * @param tickets cannot be null
	 * @return A String with all tickets spaced out
	 */
	public String ticketCollectionToString(ArrayList<Ticket> tickets) {
		if (tickets == null) {
			throw new IllegalArgumentException("Tickets cannot be null");
		}
		String string = "";
		for (int i = 0; i < tickets.size(); i++) {
			Ticket ticket = tickets.get(i);
			string = string + this.ticketToString(ticket);
		}
		return string;
	}
	
	/** Returns a String with Passenger information
	 * 
	 * @param passenger cannot be null
	 * 
	 * @return String of passenger information
	 */
	public String passengerToString(Passenger passenger) {
		if (passenger == null) {
			throw new IllegalArgumentException("Passenger cannot be null");
		}
		String string = passenger.getName() + " " + passenger.getId() + "\n";
		return string;
	}
}
