package edu.westga.cs1301.p2.view;

import java.util.ArrayList;

import edu.westga.cs1301.p2.model.Passenger;
import edu.westga.cs1301.p2.model.Ticket;
import edu.westga.cs1301.p2.model.TicketBroker;
import edu.westga.cs1301.p2.view.format.DataSummarizer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * CodeBehind To Handle Processing for the MainWindow
 *
 * @author	CS 1301
 * @version Summer 2023
 */
public class MainWindow {      
    private DataSummarizer summarizer;
    private TicketBroker ticketBroker = new TicketBroker();    
    
    @FXML private TextArea outputBox;
    @FXML private TextField ticketId;
    @FXML private TextField ticketCost;
    @FXML private TextField ticketDepartureName;
    @FXML private TextField ticketDestinationName;
    @FXML private TextField passengerId;
    @FXML private TextField passengerName;
    @FXML private TextField layOverLocationName;

    @FXML
    void addTicket(ActionEvent event) {
    	int ticketId = Integer.parseInt(this.ticketId.getText());
    	double ticketCost = Double.parseDouble(this.ticketCost.getText());
    	String ticketDepartureName = this.ticketDepartureName.getText();
    	String ticketDestinationName = this.ticketDestinationName.getText();
    	Ticket ticket = new Ticket(ticketId, ticketCost, ticketDepartureName, ticketDestinationName);
    	this.ticketBroker.addTicket(ticket);
    	String string = this.summarizer.ticketToString(ticket);
    	this.outputBox.appendText(string);
    }

    @FXML
    void findDestinationsAvailableFromDepartureLocation(ActionEvent event) {
    	String ticketDepartureName = this.ticketDepartureName.getText();
    	ArrayList<Ticket> tickets = this.ticketBroker.getDestinationsFromDeparture(ticketDepartureName);
    	String string = this.summarizer.ticketCollectionToString(tickets);
    	this.outputBox.appendText(string);

    }

    @FXML
    void findTicketsFromDepartureLocationToDestinationLocation(ActionEvent event) {
    	String ticketDepartureName = this.ticketDepartureName.getText();
    	String ticketDestinationName = this.ticketDestinationName.getText();
    	ArrayList<Ticket> tickets = this.ticketBroker.getTicketsMatchingDestinationAndDeparture(ticketDepartureName, ticketDestinationName);
    	String string = this.summarizer.ticketCollectionToString(tickets);
    	this.outputBox.appendText(string);

    }

    @FXML
    void addPassenger(ActionEvent event) {
    	int id = Integer.parseInt(this.passengerId.getText());
    	String name = this.passengerName.getText();
    	Passenger passenger = new Passenger(name, id);
    	this.ticketBroker.addPassenger(passenger);
    	String string = this.summarizer.passengerToString(passenger);
    	this.outputBox.appendText(string);

    }

    @FXML
    void purchaseTicket(ActionEvent event) {
    	int ticketId = Integer.parseInt(this.ticketId.getText());
    	int passengerId = Integer.parseInt(this.passengerId.getText());
    	String string = this.summarizer.passengerToString(this.ticketBroker.addTicketToPassenger(passengerId, ticketId));
    	this.outputBox.appendText(string);

    }

    @FXML
    void findBestPrice(ActionEvent event) {
    	String departureLocation = this.ticketDepartureName.getText();
    	String destinationLocation = this.ticketDestinationName.getText();
    	String string = this.summarizer.ticketToString(this.ticketBroker.getLowestPriceTicket(departureLocation, destinationLocation));
    	this.outputBox.appendText(string);

    }

    @FXML
    void addLayOver(ActionEvent event) {
    	this.outputBox.setText("addLayOver not yet implemented");

    }

    
	/**
	 * Handle initialization checks for the JavaFX components, and perform any
	 * necessary custom initialization.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 */
    @FXML
    void initialize() {
    	this.summarizer = new DataSummarizer();
    	this.ticketBroker = new TicketBroker();
    }
}
