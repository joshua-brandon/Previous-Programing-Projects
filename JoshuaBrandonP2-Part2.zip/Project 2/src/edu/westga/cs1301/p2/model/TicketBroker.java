package edu.westga.cs1301.p2.model;

import java.util.ArrayList;

/** Store and manage the data for a TicketBroker.
 * 
 * @author CS 1301
 * @version Summer 2023
 */
public class TicketBroker {
	private ArrayList<Ticket> tickets;
	private ArrayList<Passenger> passengers;
	
	/** Gets the list of tickets
	 * 
	 * @return ArrayList<Ticket>
	 */
	public ArrayList<Ticket> getTickets() {
		return this.tickets;
	}
	
	/** Gets the list of passenger
	 * 
	 * @return Array:ist<Passenger>
	 */
	public ArrayList<Passenger> getPassengers() {
		return this.passengers;
	}
	
	/** Makes an empty list of tickets and an empty list of passengers
	 * 
	 */
	public TicketBroker() {
		this.tickets = new ArrayList<Ticket>();
		this.passengers = new ArrayList<Passenger>();
	}
	
	/** Adds a ticket to the Ticket list
	 * 
	 * @param ticket cannot be null
	 * 
	 */
	public void addTicket(Ticket ticket) {
		if (ticket == null) {
			throw new IllegalArgumentException("Ticket cannot be null");
		}
		this.tickets.add(ticket);
	}
	
	/** Adds a passenger to the passenger list
	 *
	 * @param passenger
	 *
	 */
	public void addPassenger(Passenger passenger) {
		if (passenger == null) {
			throw new IllegalArgumentException("Passenger cannot be null");
		}
		this.passengers.add(passenger);
	}
	
	
	/** Takes a departure location and returns all possible destinations
	 * 
	 * @param departureLocation must be valid
	 * 
	 * @return a list of destinations
	 */
	public ArrayList<Ticket> getDestinationsFromDeparture(String departureLocation) {
		if (departureLocation == null) {
			throw new IllegalArgumentException("departureLocation Cannot be null");
		}
		if (departureLocation.equals("")) {
			throw new IllegalArgumentException("departureLocation Cannot be empty");
		}
		ArrayList<Ticket> validTickets = new ArrayList<Ticket>();
		for (int i = 0; i < this.tickets.size(); i++) {
			if (this.tickets.get(i).getDepartureName().equals(departureLocation)) {
				validTickets.add(this.tickets.get(i));
			}
		}
		return validTickets;
	}
	/**Makes a list of tickets that match departure and destination locations
	 * 
	 * @param departure must be valid
	 * @param destination must be valid
	 * @return a list of valid tickets
	 */
	
	public ArrayList<Ticket> getTicketsMatchingDestinationAndDeparture(String departure, String destination) {
		if (departure == null) {
			throw new IllegalArgumentException("departure Cannot be null");
		}
		if (departure.equals("")) {
			throw new IllegalArgumentException("departure Cannot be empty");
		}
		if (destination == null) {
			throw new IllegalArgumentException("destination Cannot be null");
		}
		if (destination.equals("")) {
			throw new IllegalArgumentException("destination Cannot be empty");
		}
		ArrayList<Ticket> validTickets = new ArrayList<Ticket>();
		for (Ticket currentTicket : this.tickets) {
			if (currentTicket.getDepartureName().equals(departure) && currentTicket.getDestinationName().equals(destination)) {
				validTickets.add(currentTicket);
			}
		}
		return validTickets;
	}
	
	/** Adds a Ticket to a passenger then returns the passenger
	 * 
	 * @param passengerId
	 * @param ticketId
	 * 
	 * @return a passenger with added ticket
	 */
	public Passenger addTicketToPassenger(int passengerId, int ticketId) {
		if (ticketId <= 0) {
			throw new IllegalArgumentException("ticketId must be positive");
		}
		if (passengerId <= 0) {
			throw new IllegalArgumentException("passengerId must be positive");
		}
		boolean e = false;
		boolean validTicket = e;
		int ticketLocation = 0;
		for (int i = 0; i < this.tickets.size(); i++) {
			if (this.tickets.get(i).getId() == ticketId) {
				ticketLocation = i;
				validTicket = true;
			}
		}
		if (validTicket == e) {
			throw new IllegalArgumentException("ticketId must be in Tickets");
		}
		boolean validPassenger = e;
		int passengerLocation = 0;
		for (int i = 0; i < this.passengers.size(); i++) {
			if (this.passengers.get(i).getId() == ticketId) {
				passengerLocation = i;
				validPassenger = true;
			}
		}
		if (validPassenger == e) {
			throw new IllegalArgumentException("passengerId must be in Passengers");
		}
		this.passengers.get(passengerLocation).addTicketToPassengerList(this.tickets.get(ticketLocation));
		return this.passengers.get(passengerLocation);
	}
	
	/**Gets lowest price for a ticket
	 * 
	 * @param startLocation cannot be null or empty
	 * @param endLocation cannot be null or empty
	 * 
	 * @return ticket with lowest price between two locations
	 */
	public Ticket getLowestPriceTicket(String startLocation, String endLocation) {
		if (startLocation == null) {
			throw new IllegalArgumentException("startLocation cannot be null");
		}
		if (startLocation.equals("")) {
			throw new IllegalArgumentException("startLocation cannot be empty");
		}
		if (endLocation == null) {
			throw new IllegalArgumentException("endLocation cannot be null");
		}
		if (endLocation.equals("")) {
			throw new IllegalArgumentException("endLocation cannot be empty");
		}
		
		ArrayList<Ticket> correct = this.getTicketsMatchingDestinationAndDeparture(startLocation, endLocation);
		double minPrice = 1000000;
		int ticketLocation = -1;
		if (correct.size() == 0) {
			throw new IllegalArgumentException("List must be larger than 0");
		}
		for (int i = 0; i < correct.size(); i++) {
			if (correct.get(i).getCost() < minPrice) {
				minPrice = correct.get(i).getCost();
				ticketLocation = i;
			}
		}
		return correct.get(ticketLocation);
	}
	
}
