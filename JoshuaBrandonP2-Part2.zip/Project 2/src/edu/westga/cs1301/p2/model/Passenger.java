package edu.westga.cs1301.p2.model;

import java.util.ArrayList;

/** Store and manage the data for a Passenger.
 * 
 * @author CS 1301
 * @version Summer 2023
 */
public class Passenger {
	private String name;
	private int id;
	private ArrayList<Ticket> tickets;
	
	/** Gets the name of a passenger
	 * 
	 * @return a name
	 */
	public String getName() {
		return this.name;
	}
	
	/** Gets the id of a passenger
	 * 
	 * @return a id
	 */
	public int getId() {
		return this.id;
	}
	
	/** Gets the ticket list of a passenger
	 * 
	 * @return a list of tickets
	 */
	public ArrayList<Ticket> getTickets() {
		return this.tickets;
	}
	
	/** Makes a passenger using Name and id
	 * 
	 * @param name
	 * @param id
	 */
	public Passenger(String name, int id) {
		if (name == null) {
			throw new IllegalArgumentException("Name cannot be null");
		}
		if (name.equals("")) {
			throw new IllegalArgumentException("Name cannot be empty");
		}
		if (id <= 0) {
			throw new IllegalArgumentException("Id must be a positive number");
		}
		this.name = name;
		this.id = id;
		this.tickets = new ArrayList<Ticket>();
	}
	/**Adds a ticket to a passengers list
	 * 
	 * @param ticket
	 */
	
	public void addTicketToPassengerList(Ticket ticket) {
		if (ticket == null) {
			throw new IllegalArgumentException("Ticket cannot be null");
		}
		this.tickets.add(ticket);
	}

}
