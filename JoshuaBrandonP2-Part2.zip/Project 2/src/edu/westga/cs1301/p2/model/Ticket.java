package edu.westga.cs1301.p2.model;

/** Store and manage the data for a Ticket.
 * 
 * @author CS 1301
 * @version Summer 2023
 */
public class Ticket {
	private int id;
	private double cost;
	private String departureName;
	private String destinationName;
	
	/** Gets the Id
	 * 
	 * @return id
	 */
	public int getId() {
		return this.id;
	}
	
	/** Gets the Cost
	 * 
	 * @return cost
	 */
	public double getCost() {
		return this.cost;
	}
	
	/** Gets the Departure location name
	 * 
	 * @return departureName
	 */
	public String getDepartureName() {
		return this.departureName;
	}
	
	/** Gets the Destination location name
	 * 
	 * @return destinationName
	 */
	public String getDestinationName() {
		return this.destinationName;
	}
	
	/**  Creates a Ticket
	 * 
	 * @param id >= 0
	 * @param cost >= 0
	 * @param departureName must be at least one character
	 * @param destinationName must be at least one character
	 * 
	 * 
	 */
	public Ticket(int id, double cost, String departureName, String destinationName) {
		if (id <= 0) {
			throw new IllegalArgumentException("Id must be a positive number");
		}
		if (cost <= 0) {
			throw new IllegalArgumentException("Cost must be a positive number");
		}
		if (departureName == null) {
			throw new IllegalArgumentException("Departure name cannot be null");
		}
		if (departureName.equals("")) {
			throw new IllegalArgumentException("Departure name cannot be empty");
		}
		if (destinationName == null) {
			throw new IllegalArgumentException("Destination name cannot be null");
		}
		if (destinationName.equals("")) {
			throw new IllegalArgumentException("Destination name cannot be empty");
		}
		
		this.id = id;
		this.cost = cost;
		this.departureName = departureName;
		this.destinationName = destinationName;
	}
	
}
